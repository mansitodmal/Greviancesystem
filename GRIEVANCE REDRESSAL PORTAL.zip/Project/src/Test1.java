import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Test1 extends JFrame implements ActionListener {
private JPanel contentPane;
private JTextField textField;
private JLabel lblPassword;
private JButton btnNewButton;
private JFrame test2;
private JPasswordField passwordField;
/**
* Launch the application.
*/
public static void main(String[] args) {
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
Test1 frame = new Test1();
frame.setVisible(true);
frame.setSize(450,450);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}

/**
* Create the frame.
*/
public Test1() {
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
contentPane = new JPanel();
contentPane.setLayout(new FlowLayout());
setContentPane(contentPane);
JLabel lblNewLabel = new JLabel("             LOGIN FORM          ");
lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(lblNewLabel);
JLabel lblUsername = new JLabel("  USERNAME:                    ");
lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 20));
contentPane.add(lblUsername);
textField = new JTextField(10);
contentPane.add(textField);
lblPassword = new JLabel("  PASSWORD:                   ");
lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
contentPane.add(lblPassword);
passwordField = new JPasswordField(10);
contentPane.add(passwordField);
btnNewButton = new JButton("LOGIN");
btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(btnNewButton);
btnNewButton.addActionListener(this);
}
public void actionPerformed(ActionEvent e) {
try{
	String url = "jdbc:mysql://localhost:3306/";
    String dbName = "project";
    String driver = "com.mysql.cj.jdbc.Driver";
    String userName = "root";
    String pass = "";
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","root","");
//Connection con=DriverManager.getConnection(url + dbName);
//Class.forName("com.mysql.jdbc.Driver");
//Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","","");
String user_l=textField.getText();
String pass_l=passwordField.getText();
String query="SELECT `username` , `password` FROM `register` WHERE username = ? AND password = ?";
PreparedStatement st=con.prepareStatement(query);
st.setString(1, user_l);
st.setString(2, pass_l);
ResultSet rs=st.executeQuery();
if(rs.next())
{
Test3 a=new Test3(user_l);
a.setVisible(true);
}
else
{
JOptionPane.showMessageDialog(null, "Please Enter Valid Username/Password");
}
}catch(Exception ee)
{
System.out.println(ee);
}
}
}
