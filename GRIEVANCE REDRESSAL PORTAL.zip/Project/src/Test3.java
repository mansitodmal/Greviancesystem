import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Test3 extends JFrame implements ActionListener{
private JPanel contentPane;
JFrame test1;
private JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9;
private JButton btnNewButton;
private JLabel L1,L2,L3,L4,L5,L6,L7,L8,L9,L10;
private JLabel lblWelcome;
private String st1;
private JLabel lblWelcome_1;
private JLabel label;
/**
* Launch the application.
*/
public static void main(String[] args) {
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
Test3 frame = new Test3("");
frame.setVisible(true);
frame.setSize(450, 450);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}

/**
* Create the frame.
*/
public Test3(String st1) {
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setBounds(100, 100, 450, 450);
contentPane = new JPanel();
contentPane.setLayout(new FlowLayout());
setContentPane(contentPane);
lblWelcome_1 = new JLabel("Welcome "+st1+" ! ");
lblWelcome_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(lblWelcome_1);
L1 = new JLabel("        Enter Product name         ");
L1.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L1);
t1 = new JTextField(30);
contentPane.add(t1);

L2 = new JLabel("        Enter Product Id         ");
L2.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L2);
t2 = new JTextField(30);
contentPane.add(t2);

L3 = new JLabel("        Enter Product Mfg Date         ");
L3.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L3);
t3 = new JTextField(30);
contentPane.add(t3);

L4 = new JLabel("        Enter Product Exp Date         ");
L4.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L4);
t4 = new JTextField(30);
contentPane.add(t4);

L5 = new JLabel("        Enter Product Product Size         ");
L5.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L5);
t5 = new JTextField(30);
contentPane.add(t5);

btnNewButton = new JButton("SUBMIT");
btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
contentPane.add(btnNewButton);
label = new JLabel("");
label.setForeground(SystemColor.controlHighlight);
contentPane.add(label);
label.setText(st1);
btnNewButton.addActionListener(this);
}

public void actionPerformed(ActionEvent e) {
try{
	String url = "jdbc:mysql://localhost:3306/";
    String dbName = "project";
    String driver = "com.mysql.cj.jdbc.Driver";
    String userName = "root";
    String pass = "";
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","root","");
//Connection con=DriverManager.getConnection(url + dbName);
//Class.forName("com.mysql.jdbc.Driver");
//Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","","");
String name=t1.getText();
String id=t2.getText();
String mfg=t3.getText();
String exp=t4.getText();
String size=t5.getText();
Statement st=con.createStatement();
int b=st.executeUpdate("Insert into product values('"+name+"','"+id+"','"+mfg+"','"+exp+"','"+size+"')");
JOptionPane.showMessageDialog(null, "Product Registered Successfully!!");
}catch(Exception ee)
{
System.out.println(ee);
}
}
}

