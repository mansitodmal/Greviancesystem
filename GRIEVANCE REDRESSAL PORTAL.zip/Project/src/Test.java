import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Test extends JFrame implements ActionListener {
private JPanel contentPane;
private JTextField textField;
private JFrame test1;
private JLabel L1,L2,L3,L4,L5,L6,L7,L8,L9,L10;
private JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
private JButton btnRegister;
private JButton btnLogin;
private JPasswordField p1;

/**
* Launch the application.
*/
public static void main(String[] args) {

EventQueue.invokeLater(new Runnable() {
public void run() {
try {
Test frame = new Test();
frame.setVisible(true);
frame.setSize(450, 450);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}
/**
* Create the frame.
*/
public Test() {
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
contentPane = new JPanel();
setContentPane(contentPane);
contentPane.setLayout(new FlowLayout());
JLabel L1 = new JLabel("REGISTRATION FORM");
L1.setFont(new Font("Times New Roman", Font.BOLD, 25));
contentPane.add(L1);
JLabel L2 = new JLabel(" ENTER FIRSTNAME: ");
L2.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L2);
t1 = new JTextField(30);
contentPane.add(t1);
L3 = new JLabel("ENTER LASTNAME: ");
L3.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L3);
t2=new JTextField(30);
contentPane.add(t2);
L4 = new JLabel("ENTER YOUR ADDRESS:");
L4.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L4);
t3 = new JTextField(30);
contentPane.add(t3);
L5 = new JLabel("ENTER YOUR MOBILE NUMBER:");
L5.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L5);
t4 = new JTextField(30);
contentPane.add(t4);
L6 = new JLabel("ENTER YOUR EMAIL ID:");
L6.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L6);
t5 = new JTextField(30);
contentPane.add(t5);
L7 = new JLabel("ENTER YOUR USERNAME:");
L7.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L7);
t6 = new JTextField(30);
contentPane.add(t6);
L8 = new JLabel("ENTER YOUR PASSWORD:");
L8.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(L8);
p1 = new JPasswordField(30);
contentPane.add(p1);
btnRegister=new JButton("Register");
btnRegister.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(btnRegister);
btnLogin = new JButton("LOGIN");
btnLogin.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent arg0) {
Test1 t=new Test1();
t.setVisible(true);
t.setSize(450,450);
}
});
btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 15));
contentPane.add(btnLogin);
btnRegister.addActionListener(this);
}
public void actionPerformed(ActionEvent ae) {
String firstname=t1.getText();
String lastname=t2.getText();
String address=t3.getText();
String mobile=t4.getText();
String email=t5.getText();
String username=t6.getText();
String password=p1.getText();
try {
	int id;
	  String url = "jdbc:mysql://localhost/";
	    String dbName = "project";
	    String driver = "com.mysql.cj.jdbc.Driver";
	    String userName = "root";
	    String pass = "";
Class.forName("com.mysql.cj.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost/project","root","");
//Connection con=DriverManager.getConnection(url + dbName);
Statement st=con.createStatement();
int b=st.executeUpdate("Insert into register values('"+firstname+"','"+lastname+"','"+address+"','"+mobile+"','"+email+"','"+username+"','"+password+"')");
Test1 t=new Test1();
JOptionPane.showMessageDialog(t, "Registration Successful!");
} catch (Exception e) {
// TODO Auto-generated catch block
System.out.println(e);
}
}
}
